#!/usr/bin/env node

import "./dist-client/entry-client.js";
